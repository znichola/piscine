echo 'test 1 "	 	  			 " " 	"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "	 	  			 " " 	"
echo '\ntest 2 "	 		 		" " 	"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "	 		 		" " 	"
echo '\ntest 3 "ROGMtbA" "ROGMtbA"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "ROGMtbA" "ROGMtbA"
echo '\ntest 4 "hjlyI	BP" "hjlyI	BP"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "hjlyI	BP" "hjlyI	BP"
echo '\ntest 5 "aPlYtLEObCQpOs gn4sf 8xtrb7BUTn6fw529JZ" "OpS"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "aPlYtLEObCQpOs gn4sf 8xtrb7BUTn6fw529JZ" "OpS"
echo '\ntest 6 "o5x4Fh8PRCtiEnG8G1Nwg9D3lAydYNYTPOf9E" "P1iBQwU"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "o5x4Fh8PRCtiEnG8G1Nwg9D3lAydYNYTPOf9E" "P1iBQwU"
echo '\ntest 7 "uIEKKitwKUeDrnB4pjk8r	Fhwv9Xq6t5v8F" "3Iftk"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "uIEKKitwKUeDrnB4pjk8r	Fhwv9Xq6t5v8F" "3Iftk"
echo '\ntest 8 "wNBGxJJUe4XyItW7pTwwWlnI6KAp4" "6d0Skt"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "wNBGxJJUe4XyItW7pTwwWlnI6KAp4" "6d0Skt"
echo '\ntest 9 "4yNoDtgczv6136T0JKMXbvJHuwcbXy3u01 bsOsBDdBLAN" "5pxkJ	Uy"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "4yNoDtgczv6136T0JKMXbvJHuwcbXy3u01 bsOsBDdBLAN" "5pxkJ	Uy"
echo '\ntest 10 "Q2uPWwYUgSnWdgA	MK SEdBxSFq8i2o" "Lmg7"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "Q2uPWwYUgSnWdgA	MK SEdBxSFq8i2o" "Lmg7"
echo '\ntest 11 "  gh  " " gh"'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "  gh  " " gh"
echo '\ntest 12 "  gh  " " "'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "  gh  " " "
echo '\ntest 13 "mSErQ9t6nlObFEA81IGU72lEv8Ht58QsJl eBydoh4" """'
gcc -Wall -Werror -Wextra main.c ../ft_split.c && ./a.out "mSErQ9t6nlObFEA81IGU72lEv8Ht58QsJl eBydoh4" ""

