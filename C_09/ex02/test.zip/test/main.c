#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

char	**ft_split(char *str, char *charset);

int main(int ac, char **av)
{
	char *str = av[1];
	char *sep = av[2];
	char **foo = ft_split(str, sep);

	if (ac != 3)
	{
		printf("give me some arguments you piece \n");
		return (0);
	}

	printf("tab start\n");
	for (int i = 0; foo[i] != 0; i++)
		printf("tab[%d]: \"%s\"\n", i, foo[i]);
	printf("tab end\n");
	return (0);
}